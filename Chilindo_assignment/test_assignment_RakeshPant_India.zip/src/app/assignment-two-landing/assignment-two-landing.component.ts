import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment-two-landing',
  templateUrl: './assignment-two-landing.component.html',
  styleUrls: ['./assignment-two-landing.component.css']
})
export class AssignmentTwoLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
