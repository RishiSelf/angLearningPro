import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accept-application',
  templateUrl: './accept-application.component.html',
  styleUrls: ['./accept-application.component.css']
})
export class AcceptApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
