import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employment-info',
  templateUrl: './employment-info.component.html',
  styleUrls: ['./employment-info.component.css']
})
export class EmploymentInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
