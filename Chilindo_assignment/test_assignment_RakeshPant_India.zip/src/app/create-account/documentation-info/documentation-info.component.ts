import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-documentation-info',
  templateUrl: './documentation-info.component.html',
  styleUrls: ['./documentation-info.component.css']
})
export class DocumentationInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
