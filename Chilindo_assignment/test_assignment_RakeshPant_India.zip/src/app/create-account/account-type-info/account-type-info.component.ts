import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-type-info',
  templateUrl: './account-type-info.component.html',
  styleUrls: ['./account-type-info.component.css']
})
export class AccountTypeInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
