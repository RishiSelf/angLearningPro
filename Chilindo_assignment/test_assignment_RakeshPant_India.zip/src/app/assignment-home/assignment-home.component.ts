import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment-home',
  templateUrl: './assignment-home.component.html',
  styleUrls: ['./assignment-home.component.css']
})
export class AssignmentHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
