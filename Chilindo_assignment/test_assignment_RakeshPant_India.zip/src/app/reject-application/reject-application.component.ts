import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reject-application',
  templateUrl: './reject-application.component.html',
  styleUrls: ['./reject-application.component.css']
})
export class RejectApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
